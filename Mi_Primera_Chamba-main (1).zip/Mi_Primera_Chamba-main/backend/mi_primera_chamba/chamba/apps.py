from django.apps import AppConfig


class ChambaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'chamba'
